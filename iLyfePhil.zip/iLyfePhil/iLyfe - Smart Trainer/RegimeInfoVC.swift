//
//  RegimeInfoVC.swift
//  iLyfe - Smart Trainer
//
//  Created by ITP312 on 5/7/19.
//  Copyright © 2019 NYP. All rights reserved.
//

import UIKit
import FirebaseDatabase

class RegimeInfoVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var exercisesTableView: UITableView!
    
    // Selected Body Parts
    var bodyParts: [String] = []
    var exerciseArray1: [[String]] = []
    var exerciseIndex = 0
    var exercise: String = ""
    
    struct Objects{
        var sectionName : String!
        var sectionObjects : [String]!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(bodyParts)
        
        for bodyPart in bodyParts{
        var exerciseRef = Database.database().reference()
            exerciseRef.child("Exercises").child(bodyPart).observeSingleEvent(of: .value, with: {
                (snapshot) in
                var exerciseArray: [String] = []
                for exercise in snapshot.children{
                    let exercise = exercise as! DataSnapshot
                    exerciseArray.append(String(exercise.key))
                    if exerciseArray.count == 2{
                    self.exerciseArray1.append(exerciseArray)
                    }
                }
                self.exercisesTableView.reloadData()
            })
        }
    }
    
    // Set number of rows per section
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.exerciseArray1[section].count
    }
    
    // Set number of sections
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.exerciseArray1.count
    }
    
    // Set header for section division
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return bodyParts[section]
    }
    
    // Set content of table cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        print(self.exerciseArray1)
        cell.textLabel?.text = self.exerciseArray1[indexPath.section][indexPath.row]
        return cell
    }
    var bodyPartSelection = ""
    
    // Segue for ViewHistoryVC.swift
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "StartRegime"
        {
            // Combine bodyParts array to a single string
            for bodyPart in bodyParts{
                // Add comma to body parts not in the last index
                if bodyParts[bodyParts.count-1] != bodyPart{
                    bodyPartSelection = bodyPartSelection + bodyPart + ", "
                }else{
                    bodyPartSelection = bodyPartSelection + bodyPart
                }
            }
            
            // Set exercise dictionary
            var exercise : [String: Any]
            exercise = ["Push Ups": 0,
                        "Sit Ups": 0]
            
            // Add bodyParts array to firebase
            var ref = FirebaseDatabase.Database.database().reference().child("Selections").childByAutoId().child("\(bodyPartSelection)")
            for bodyPart in bodyParts{
                ref.child("\(bodyPart)").setValue(exercise)
            }
            // Send Info to RegimeVC
            let SelectVC = segue.destination as! RegimeVC
            SelectVC.bodyParts = bodyParts
        }else if segue.identifier == "ExerciseInfo" {
            // Send Info to ExerciseInfoVC
            let ExerciseInfoVC = segue.destination as! ExerciseInfoVC
            let selectedRow = exercisesTableView.indexPathForSelectedRow
            exercise = exerciseArray1[selectedRow![0]][selectedRow![1]]
            ExerciseInfoVC.exercise = exercise
        }
    }

}
