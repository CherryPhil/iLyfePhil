//
//  RegimeInfoVC.swift
//  iLyfe - Smart Trainer
//
//  Created by ITP312 on 5/7/19.
//  Copyright © 2019 NYP. All rights reserved.
//

import UIKit
import FirebaseDatabase

class RegimeInfoVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var exercisesTableView: UITableView!
    
    // Selected Body Parts
    var bodyParts : [String] = []
    
    struct Objects{
        var sectionName : String!
        var sectionObjects : [String]!
    }
    
    var objectsArray = [Objects]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(bodyParts)
    }
    
    // Set number of rows per section
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    // Set number of sections
    func numberOfSections(in tableView: UITableView) -> Int {
        return bodyParts.count
    }
    
    // Set header for section division
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return bodyParts[section]
    }
    
    // Set content of table cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        cell.textLabel?.text = "Push Ups"
        return cell
    }
    
    
    var bodyPartSelection = ""
    
    // Segue for ViewHistoryVC.swift
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "StartRegime"
        {
            // Combine bodyParts array to a single string
            for bodyPart in bodyParts{
                // Add comma to body parts not in the last index
                if bodyParts[bodyParts.count-1] != bodyPart{
                    bodyPartSelection = bodyPartSelection + bodyPart + ", "
                }else{
                    bodyPartSelection = bodyPartSelection + bodyPart
                }
            }
            
            // Set exercise dictionary
            var exercise : [String: Any]
            exercise = ["Push Ups": 0,
                        "Sit Ups": 0]
            
            // Add bodyParts array to firebase
            var ref = FirebaseDatabase.Database.database().reference().child("Selections").childByAutoId().child("\(bodyPartSelection)")
            for bodyPart in bodyParts{
                ref.child("\(bodyPart)").setValue(exercise)
            }
            let SelectVC = segue.destination as! RegimeVC
            SelectVC.bodyParts = bodyParts
        }else if segue.identifier == "ExerciseInfo" {
            let ExerciseInfoVC = segue.destination as1 ExerciseInfoVC
        }
    }

}
