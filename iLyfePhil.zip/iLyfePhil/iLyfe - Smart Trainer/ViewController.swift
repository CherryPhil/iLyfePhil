//
//  ViewController.swift
//  iLyfe - Smart Trainer
//
//  Created by ITP312 on 25/6/19.
//  Copyright © 2019 NYP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

