//
//  RegimeVC.swift
//  iLyfe - Smart Trainer
//
//  Created by ITP312 on 2/7/19.
//  Copyright © 2019 NYP. All rights reserved.
//

import UIKit
import CoreMotion
import CoreML

class RegimeVC: UIViewController {
    
    @IBOutlet weak var startTimerBtn: UIButton!
    @IBOutlet weak var Reps: UILabel!
    @IBOutlet weak var CountdownLabel: UILabel!
    @IBOutlet weak var speechText: UILabel!
    
    let speechRecognizer = SpeechRecognizer()
    let speechSynthesizer = SpeechSynthesizer()
    var isSpeechOnRepeat = false
    
    // Selected Body Parts
    var bodyParts : [String] = []
    
    // Timer variables
    var duration = 60
    lazy var seconds = duration
    var timer = Timer()
    var isTimerRunning = false
    var resumeTapped = false
    
    // AC Variables
    struct ModelConstants {
        static let numOfFeatures = 6
        static let predictionWindowSize = 50
        static let sensorsUpdateInterval = 1.0 / 50.0
        static let hiddenInLength = 200
        static let hiddenCellInLength = 200
    }
    let activityClassificationModel = MyActivityClassifier()
    
    var currentIndexInPredictionWindow = 0
    let predictionWindowDataArray = try? MLMultiArray(shape: [1 , ModelConstants.predictionWindowSize , ModelConstants.numOfFeatures] as [NSNumber], dataType: MLMultiArrayDataType.double)
    var lastHiddenOutput = try? MLMultiArray(shape:[ModelConstants.hiddenInLength as NSNumber], dataType: MLMultiArrayDataType.double)
    var lastHiddenCellOutput = try? MLMultiArray(shape:[ModelConstants.hiddenCellInLength as NSNumber], dataType: MLMultiArrayDataType.double)
    
    // Exercise Counts
    var current = 0
    var target = 30
    
    // Call runTimer()
    @IBAction func StartTimerBtn(_ sender: UIButton) {
        if isTimerRunning == false{
            runTimer()
            recordSpeech()
            isSpeechOnRepeat = true
        }
    }
    // Toggle Pause
    @IBAction func PauseTimerBtn(_ sender: UIButton) {
        // Invalidate Timer
        if self.resumeTapped == false{
            timer.invalidate()
            isTimerRunning = false
            self.resumeTapped = true
        // Validate Timer
        }else{
            runTimer()
            isTimerRunning = true
            self.resumeTapped = false
        }
    }
    
    // Format seconds to a String, (Min : Sec).
    func timeString(time: TimeInterval) -> String {
        let min = Int(time) / 60 % 60
        let sec = Int(time) % 60
        return String(format: "%02i:%02i", min, sec)
    }
    
    // Start Timer
    func runTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(RegimeVC.updateTimer)), userInfo: nil, repeats: true)
        isTimerRunning = true
    }
    
    // Update Timer
    @objc func updateTimer() {
        // Update Countdown Label
        if seconds > 0 {
            seconds -= 1
            CountdownLabel.text = timeString(time: TimeInterval(seconds))
        // End Timer Countdown
        }else{
            print("Time is up!")
            timer.invalidate()
            isTimerRunning = false
            isSpeechOnRepeat = false
            self.speechSynthesizer.speak(text: "You've completed " + String(current) + " push ups!" )
            speechText.text = "You've completed " + String(current) + " push ups!"
        }
    }
    
    // Set default time for countdown label
    override func viewDidLoad() {
        super.viewDidLoad()
        CountdownLabel.text = timeString(time: TimeInterval(seconds))
        print(bodyParts)
    }
    
    
    
    // Motion Manager
    var motionManager = CMMotionManager()
    
    // Set to update every 0.3 seconds
    override func viewDidAppear(_ animated: Bool) {
        
        
        //motionManager.isAccelerometerAvailable && motionManager.isGyroAvailable else { return }
        
        motionManager.accelerometerUpdateInterval = TimeInterval(ModelConstants.sensorsUpdateInterval)
        motionManager.gyroUpdateInterval = TimeInterval(ModelConstants.sensorsUpdateInterval)
        
        motionManager.startAccelerometerUpdates(to: .main) { accelerometerData, error in
            guard let accelerometerData = accelerometerData else { return }
            // Add the current data sample to the data array
            self.addAccelSampleToDataArray(accelSample: accelerometerData)
        }
        
        
//        motionManager.accelerometerUpdateInterval = 0.3
//
//        motionManager.startAccelerometerUpdates(to: OperationQueue.current!) { (data, error) in
//            if let myData = data
//            {
//                // Determine sensitivity of acceleration
//                print(myData)
//                if self.isTimerRunning == true && myData.acceleration.x > 1 && myData.acceleration.y > 1
//                {
//                    print("Push up")
//                    self.current = self.current + 1
//                    self.Reps.text = "\(self.current)/\(self.target)"
//                }
//            }
//        }
    }
    
    func addAccelSampleToDataArray (accelSample: CMAccelerometerData) {
        // Add the current accelerometer reading to the data array
        guard let dataArray = predictionWindowDataArray else { return }
        dataArray[[0 , currentIndexInPredictionWindow ,0] as [NSNumber]] = accelSample.acceleration.x as NSNumber
        dataArray[[0 , currentIndexInPredictionWindow ,1] as [NSNumber]] = accelSample.acceleration.y as NSNumber
        dataArray[[0 , currentIndexInPredictionWindow ,2] as [NSNumber]] = accelSample.acceleration.z as NSNumber
        
        // Update the index in the prediction window data array
        currentIndexInPredictionWindow += 1
        
        // If the data array is full, call the prediction method to get a new model prediction.
        // We assume here for simplicity that the Gyro data was added to the data array as well.
        if (currentIndexInPredictionWindow == ModelConstants.predictionWindowSize) {
            let predictedActivity = performModelPrediction() ?? "N/A"
            
            // Use the predicted activity here
            // ...
            
            // Start a new prediction window
            currentIndexInPredictionWindow = 0
        }
    }
    
    func performModelPrediction () -> String? {
        guard let dataArray = predictionWindowDataArray else { return "Error!"}
        
        // Perform model prediction
        let modelPrediction = try? activityClassificationModel.prediction(features: dataArray, hiddenIn: lastHiddenOutput, cellIn: lastHiddenCellOutput)
        
        // Update the state vectors
        if (isTimerRunning){
            lastHiddenOutput = modelPrediction?.hiddenOut
            lastHiddenCellOutput = modelPrediction?.cellOut
            print(modelPrediction?.activity)
        }
        if (modelPrediction?.activity == "climbing_downstairs"){
            print("Push up")
            self.current = self.current + 1
            self.Reps.text = "\(self.current)/\(self.target)"
        }
        
        // Return the predicted activity - the activity with the highest probability
        return modelPrediction?.activity
    }
    
    func recordSpeech(){
        self.speechSynthesizer.stop()
        if !speechRecognizer.isRunning{
            
            speechRecognizer.startRecognition(onReceivedTranscription: {
                recognizedString in
                DispatchQueue.main.async {
                    self.speechText.text = recognizedString
                }
            }, onStoppedRecognizing: {
                recognizedString in
                
                DispatchQueue.main.async {
                    self.speechText.text = recognizedString
                    
                    let trimmedResult = recognizedString.lowercased().trimmingCharacters(in: [" "])
                    
                    if trimmedResult == "down"{
                        self.current = self.current + 1
                    }else if trimmedResult == "downdown"{
                        self.current = self.current + 2
                    }else{
                        print("Said Nothing")
                    }
                    if self.isSpeechOnRepeat == true{
                        self.recordSpeech()
                        print("speechisonrepeat")
                        self.Reps.text = "\(self.current)/\(self.target)"
                    }
                }
            })
        }
    }
}
