//
//  RegimeVC.swift
//  iLyfe - Smart Trainer
//
//  Created by ITP312 on 2/7/19.
//  Copyright © 2019 NYP. All rights reserved.
//

import UIKit
import CoreMotion

class RegimeVC: UIViewController {
    
    @IBOutlet weak var startTimerBtn: UIButton!
    @IBOutlet weak var Reps: UILabel!
    @IBOutlet weak var CountdownLabel: UILabel!
    @IBOutlet weak var speechText: UILabel!
    
    let speechRecognizer = SpeechRecognizer()
    let speechSynthesizer = SpeechSynthesizer()
    var isSpeechOnRepeat = false
    
    // Selected Body Parts
    var bodyParts : [String] = []
    
    // Timer variables
    var duration = 60
    lazy var seconds = duration
    var timer = Timer()
    var isTimerRunning = false
    var resumeTapped = false
    
    // Exercise Counts
    var current = 0
    var target = 30
    
    // Call runTimer()
    @IBAction func StartTimerBtn(_ sender: UIButton) {
        if isTimerRunning == false{
            runTimer()
            recordSpeech()
            isSpeechOnRepeat = true
        }
    }
    // Toggle Pause
    @IBAction func PauseTimerBtn(_ sender: UIButton) {
        // Invalidate Timer
        if self.resumeTapped == false{
            timer.invalidate()
            isTimerRunning = false
            self.resumeTapped = true
        // Validate Timer
        }else{
            runTimer()
            isTimerRunning = true
            self.resumeTapped = false
        }
    }
    
    // Format seconds to a String, (Min : Sec).
    func timeString(time: TimeInterval) -> String {
        let min = Int(time) / 60 % 60
        let sec = Int(time) % 60
        return String(format: "%02i:%02i", min, sec)
    }
    
    // Start Timer
    func runTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(RegimeVC.updateTimer)), userInfo: nil, repeats: true)
        isTimerRunning = true
    }
    
    // Update Timer
    @objc func updateTimer() {
        // Update Countdown Label
        if seconds > 0 {
            seconds -= 1
            CountdownLabel.text = timeString(time: TimeInterval(seconds))
        // End Timer Countdown
        }else{
            print("Time is up!")
            timer.invalidate()
            isTimerRunning = false
            isSpeechOnRepeat = false
            self.speechSynthesizer.speak(text: "You've completed " + String(current) + " push ups!" )
            speechText.text = "You've completed " + String(current) + " push ups!"
        }
    }
    
    // Set default time for countdown label
    override func viewDidLoad() {
        super.viewDidLoad()
        CountdownLabel.text = timeString(time: TimeInterval(seconds))
        print(bodyParts)
    }
    
    
    
    // Motion Manager
    var motionManager = CMMotionManager()
    
    // Set to update every 0.3 seconds
    override func viewDidAppear(_ animated: Bool) {
        motionManager.accelerometerUpdateInterval = 0.3
        
        motionManager.startAccelerometerUpdates(to: OperationQueue.current!) { (data, error) in
            if let myData = data
            {
                // Determine sensitivity of acceleration
                if self.isTimerRunning == true && myData.acceleration.x > 1 && myData.acceleration.y > 1
                {
                    print("Push up")
                    self.current = self.current + 1
                    self.Reps.text = "\(self.current)/\(self.target)"
                }
            }
        }
    }
    func recordSpeech(){
        self.speechSynthesizer.stop()
        if !speechRecognizer.isRunning{
            
            speechRecognizer.startRecognition(onReceivedTranscription: {
                recognizedString in
                
                DispatchQueue.main.async {
                    self.speechText.text = recognizedString
                }
            }, onStoppedRecognizing: {
                recognizedString in
                
                
                DispatchQueue.main.async {
                    self.speechText.text = recognizedString
                    
                    let trimmedResult = recognizedString.lowercased().trimmingCharacters(in: [" "])
                    
                    if trimmedResult == "one"{
                        self.current = self.current + 1
                    }else if trimmedResult == "11"{
                        self.current = self.current + 2
                    }
                    if self.isSpeechOnRepeat == true{
                        self.recordSpeech()
                        print("speechisonrepeat")
                        self.Reps.text = "\(self.current)/\(self.target)"
                    }
                }
            })
        }
    }
}
