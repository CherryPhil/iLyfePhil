//
//  ViewHistoryVC.swift
//  iLyfe - Smart Trainer
//
//  Created by Guest User on 9/7/19.
//  Copyright © 2019 NYP. All rights reserved.
//

import UIKit
import FirebaseDatabase

struct regimeStruct {
    var regimeName : String!
}

class ViewHistoryVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var regimeArray: [String] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let regimeRef = Database.database().reference()
        var index = 0
        
        regimeRef.child("Selections").queryOrderedByKey().observe(.value, with: {snapshot in
            
            let result = snapshot.children.allObjects as? [DataSnapshot]
            for child in result!{
                
                let regimes = child.value as! [String: Any]
                if index == 0 {
                    self.regimeArray = Array(regimes.keys)
                    index = 1
                } else {
                    self.regimeArray = self.regimeArray + Array(regimes.keys)
                    print(self.regimeArray)
                }
            }
            self.tableView.reloadData()
        })
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return regimeArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "regimeCell")
        
        cell?.textLabel?.text = self.regimeArray[indexPath.row]
        return cell!
    }
}
