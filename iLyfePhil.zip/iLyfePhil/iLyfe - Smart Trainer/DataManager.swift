//
//  DataManager.swift
//  iLyfe - Smart Trainer
//
//  Created by ITP312 on 12/7/19.
//  Copyright © 2019 NYP. All rights reserved.
//

import UIKit

class DataManager: NSObject {

}
